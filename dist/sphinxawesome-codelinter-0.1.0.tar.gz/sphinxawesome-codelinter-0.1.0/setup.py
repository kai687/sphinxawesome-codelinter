# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'sphinxawesome'}

packages = \
['codelinter']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'sphinxawesome-codelinter',
    'version': '0.1.0',
    'description': 'A Sphinx extension that enables running linters over code blocks',
    'long_description': None,
    'author': 'Kai Welke',
    'author_email': 'kai.welke@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
